package edu.vt.cs5254.fancygallery

import edu.vt.cs5254.fancygallery.api.FlickrApi
import edu.vt.cs5254.fancygallery.api.GalleryItem
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.create

//For wrapping most of the networking code
class PhotoRepository {

    private val flickrApi: FlickrApi

    init {
        //build retrofit object
        //convert the response in the form of a string by specifying converter
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("https://api.flickr.com/")
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
        //create API instance
        flickrApi = retrofit.create()
    }

    suspend fun fetchPhotos(count : Int = 100): List<GalleryItem> =
        flickrApi.fetchPhotos(fetchCount = count).photos.galleryItems



}